<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>loginpage</title>
</head>
<body>
    <div class="login-form">
    <form method = "POST" action="">
        enter recruiter_username or seeker_username<input type="text" name="user_name">
        enter password<input type="password" name="password">
        <input type="submit" value="login" name = "btn">
    </form>
    </div>
<?php
$conn = new mysqli("localhost","root", "","job_connect" );

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_REQUEST['btn']))
{
$user_name = $_POST['user_name'];
$pass = $_POST['password'];

// Query to check recruiter table
$sql_recruiter = "SELECT * FROM recruiter WHERE recruiter_username = '$user_name' AND password = '$pass' ";
$result_recruiter=mysqli_query($conn,$sql_recruiter);
if (mysqli_num_rows($result_recruiter)>0) {
    // User found in recruiter table
    header("Location: recruiter.php");
    exit();
} else {
    // Query to check seeker table
    $sql_seeker = "SELECT * FROM seeker WHERE seeker_username = '$user_name' AND password = '$pass' ";
$result_seeker = mysqli_query($conn,$sql_seeker);
    if (mysqli_num_rows($result_seeker) > 0) {
        // User found in seeker table
        header("Location: seeker.php");
        exit();
    } else {
        // Credentials not found in either table
        echo "Invalid username or password.";
    }
}
}
// Close connection
$conn->close();
?>
</body>
</html>